export MY_SYSTEM=macos

## Uninstall Java virtual machine from Virtual System place
export JAVA_RUNTIME_PATH=`pwd`/runtime/so/$MY_SYSTEM/jdk-11.0.2.jdk
if [ -d "$JAVA_RUNTIME_PATH" ]; then
    echo "If the JDK still exists at Alfa folder means that it was not copied to the Java Virtual Machines folder. So nothing to do here"
else
    echo "The JDK does not exists here so it was moved to Java Virtual Machines folder and it is needed being removed..."
    sudo rm -fr "/Library/Java/JavaVirtualMachines/jdk-11.0.2.jdk";
    echo "JDK has been removed from Java Virtual Machines folder"
fi

## Remove buster client config from Chrome System place to setup Chrome
export DESTINATION_BUSTER_CLIENT_PATH=$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts/alfa.org.buster.client.json
rm "$DESTINATION_BUSTER_CLIENT_PATH"
echo "Alfa Buster client removed from Native Messaging Hosts"
