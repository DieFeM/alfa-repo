var onMessageHandler = function(message){
    // Ensure it is run only once, as we will try to message twice
    chrome.runtime.onMessage.removeListener(onMessageHandler);

    try {
        console.log('##POSTDATA.HTML## Loading page');
        var xhr = new XMLHttpRequest();

        xhr.open('PARAM_METHOD', message.url);
        xhr.onreadystatechange = handler;
        xhr.responseType = 'blob';
        /* It is up to the user the following headers:
            - Case form (e.g. body = 'paramForm=1&paramForm=2'):
                'Content-type', 'application/x-www-form-urlencoded'

            - Case json (e.g. body = '{"a": "a"}'):
                'Content-Type', 'application/json'
        */
        var headers = message.data.headers;  // e.g.: {"header1": "value1", "header2": "value2"}
        Object.keys(headers).forEach(function (key) {
            var value = headers[key];
            xhr.setRequestHeader(key, value);
        });
        //TODO get or post???
        var body = message.data.body;
        console.log('##POSTDATA.HTML## Body to send: ' + body);
        xhr.send(body);
    } catch (e) {
        console.error('##POSTDATA.HTML## ##Error calling URL? :(', e);
    }

    function handler() {
        if (this.readyState === this.DONE) {
            console.log('##POSTDATA.HTML## ##Return with status :' + this.status);
            //if (this.status === 200) {
            try {
                // this.response is a Blob, because we set responseType above
                var data_url = URL.createObjectURL(this.response);
                document.querySelector('#my_iframe').src = data_url;
            } catch (e) {
                console.error('##POSTDATA.HTML## ##Imposible to render on iFrame? :(', e);
            }

            /*} else {
                console.error('##POSTDATA.HTML## ##Nothing to render? :(');
            }*/
        }
    }
}
chrome.runtime.onMessage.addListener(onMessageHandler);
