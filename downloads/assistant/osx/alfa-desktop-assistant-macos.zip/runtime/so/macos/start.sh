MY_SYSTEM=macos

if [ -f "`pwd`/alfa-desktop-assistant.exe" ]; then
    echo "Alfa Desktop Assistant found"
    mkdir -p temp
else
    echo "ERROR: Alfa Desktop Assistant was NOT found"
    exit 1;
fi

#sudo update-alternatives --config java

export JAVA_HOME=/Library/Java/JavaVirtualMachines/java-11-openjdk-amd64
export MY_JAVA_PATH=$JAVA_HOME/bin/java
PATH=$JAVA_HOME:$JAVA_HOME/bin:$MY_JAVA_PATH:$PATH

$MY_JAVA_PATH -DAlfaDesktopAssistant -cp alfa-desktop-assistant.exe com.alfa.alfadesktopassistant.App open &
PID=$!
echo $PID > temp/AlfaDesktopAssistant.PID
