#!/bin/bash

if [ -f "`pwd`/alfa-desktop-assistant.exe" ]; then
    echo "Alfa Desktop Assistant found"
    mkdir -p temp
else
    echo "ERROR: Alfa Desktop Assistant was NOT found"
    exit 1;
fi

if [[ $OSTYPE == 'darwin'* ]]; then
  export MY_SYSTEM=macos
else
  export MY_SYSTEM=linux
fi

#############################################
# Install Assistant Desktop #
"`pwd`/runtime/so/$MY_SYSTEM/install.sh";

#############################################
. `pwd`/runtime/so/$MY_SYSTEM/lib.sh

# Check if it is necessary Java
getChromePath # return $retValChromePath
# Check if it is necessary Java
getJavaPath # return $retValJavaPath

# Install Chrome and Java if necessary #
function download_and_unzip() {
  echo "$1/$2"
  if test -f "$2"; then
    rm "$2"
  fi
  curl "$1/$2" -L
  exit_code=$?
  if [ $exit_code -ne 0 ]; then
    wget "$1/$2"
    exit_code=$?
    if [ $exit_code -ne 0 ]; then
      echo "##ERROR: It could not be possible to download $1$2"
      exit $exit_code
    else
      echo "#Downloaded $2 using wget"
    fi
  else
    echo "#Downloaded $2 using curl"
  fi
  if test -f "$2"; then
    unzip "$2" -d .
  else
    echo "#łERROR: No file to unzip ($2 not found)"
  fi
}

# Script parameter must be an URL where is located the zips to download
if [ -z "$1" ]
then
      echo "No URL parameter so nothing to download"
else
  # Check Chrome existence
  if [ -z "$retValChromePath" ]
  then
    # If Chrome not found then download and place it locally
    echo "Chrome was NOT found: so downloading and installing..."
    download_and_unzip "$1" alfa-desktop-assistant-chrome-$MY_SYSTEM.zip
  else
    echo $retValChromePath > chrome_used.path
    echo "Chrome was found: nothing to do"
  fi

  # Check Java existence
  if [ -z "$retValJavaPath" ]
  then
    # If Java not found then download and place it locally
    echo "Java was NOT found: so downloading and installing..."
    download_and_unzip "$1" alfa-desktop-assistant-java-$MY_SYSTEM.zip
  else
    echo $retValJavaPath > java_used.path
    echo "Java was found: nothing to do"
  fi
fi
