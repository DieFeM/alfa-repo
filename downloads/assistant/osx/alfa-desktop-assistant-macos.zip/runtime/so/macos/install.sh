export MY_SYSTEM=macos
export MY_ARCHI=x86_64   #It could be possibly different!! We need to verify it //TODO #TODO

if [ -f "`pwd`/alfa-desktop-assistant.exe" ]; then
    echo "Alfa Desktop Assistant found"
    mkdir -p temp
else
    echo "ERROR: Alfa Desktop Assistant was NOT found"
    exit 1;
fi

## Customize buster extension config
export DST_BUSTER_EXTENSION_SCRIPT_JS_PATH=`pwd`/buster-extension/src/background/script.js
export DST_BUSTER_EXTENSION_SCRIPT_JS_MAP_PATH=`pwd`/buster-extension/src/background/script.js.map
export STR_TO_SEARCH="org.buster.client"
export STR_TO_REPLACE="alfa.org.buster.client"
sed -i "s@$STR_TO_SEARCH@$STR_TO_REPLACE@gi" "$DST_BUSTER_EXTENSION_SCRIPT_JS_PATH"
sed -i "s@$STR_TO_SEARCH@$STR_TO_REPLACE@gi" "$DST_BUSTER_EXTENSION_SCRIPT_JS_MAP_PATH"

## Install Java virtual machine in Virtual System place
export JAVA_RUNTIME_PATH=`pwd`/runtime/so/$MY_SYSTEM/jdk-11.0.2.jdk
[ -d $JAVA_RUNTIME_PATH ] && sudo mv -f $JAVA_RUNTIME_PATH /Library/Java/JavaVirtualMachines/ | true
#TODO: ways to get list of Java runtime:
#    /usr/libexec/java_home -V

## Copy buster client config in Chrome System place to setup Chrome
export MY_BUSTER_CLIENT_EXE_PATH=`pwd`/runtime/so/$MY_SYSTEM/buster-client/$MY_ARCHI/alfa-buster-client
export MY_BUSTER_CLIENT_JSON_PATH=`pwd`/runtime/so/$MY_SYSTEM/buster-client/alfa.org.buster.client.json
mkdir -p "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
export DESTINATION_BUSTER_CLIENT_PATH="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts/alfa.org.buster.client.json"
cp "$MY_BUSTER_CLIENT_JSON_PATH" "$DESTINATION_BUSTER_CLIENT_PATH"
export STR_TO_SEARCH="BUSTER_CLIENT_EXECUTABLE_PATH"
export STR_TO_REPLACE="$MY_BUSTER_CLIENT_EXE_PATH"
sed -i "s@$STR_TO_SEARCH@$STR_TO_REPLACE@gi" "$DESTINATION_BUSTER_CLIENT_PATH"
