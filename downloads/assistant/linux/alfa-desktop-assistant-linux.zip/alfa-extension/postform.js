var onMessageHandler = function(message){
    // Ensure it is run only once, as we will try to message twice
    chrome.runtime.onMessage.removeListener(onMessageHandler);

    // code from https://stackoverflow.com/a/7404033/934239
    var form = document.createElement("form");
    //TODO message.data.headers ???
    form.setAttribute("method", message.data.config['_PARAM_SEND_METHOD_URL']);    // "get" | "post"
    form.setAttribute("enctype", "application/x-www-form-urlencoded");  // "application/x-www-form-urlencoded" (default) | "text/plain" | "multipart/form-data" (needs a input type=file)
    form.setAttribute("action", message.url);
    for (var key in message.data.body) {
        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", key);
        hiddenField.setAttribute("value", message.data[key]);
        form.appendChild(hiddenField);
    }
    document.body.appendChild(form);
    form.submit();
}
chrome.runtime.onMessage.addListener(onMessageHandler);
