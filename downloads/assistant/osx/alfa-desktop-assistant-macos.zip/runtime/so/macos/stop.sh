if [ -f "`pwd`/alfa-desktop-assistant.exe" ]; then
    echo "Alfa Desktop Assistant found"
    mkdir -p temp
else
    echo "ERROR: Alfa Desktop Assistant was NOT found"
    exit 1;
fi

JPS_PID="$(jps -lv | grep -i alfadesktopassistant | awk '{print $1}')"
kill $JPS_PID &
sleep 0.2
kill -9 $JPS_PID &

if [ -f "temp/AlfaDesktopAssistant.PID" ]; then
    PID=`cat temp/AlfaDesktopAssistant.PID`
    kill $PID &
    sleep 0.5
    kill -9 $PID &
    sleep 0.5
fi

kill `ps -ef|grep -i alfadesktopassistant | awk '{ print $2 }'` &
sleep 0.2
killall AlfaChrome &
sleep 0.2
kill -9 `ps -ef|grep -i alfadesktopassistant | awk '{ print $2 }'`
killall -9 AlfaChrome
