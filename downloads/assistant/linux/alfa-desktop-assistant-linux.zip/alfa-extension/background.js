/*!
 * Web Sniffer v0.0.0.3 (https://5ms.ru/sniffer/)
 * Copyright 2018, 5MS
 * Licensed under MIT (http://en.wikipedia.org/wiki/MIT_License)
 */

console.log('##Extension ' + chrome.runtime.id + ' activated! Background');

var tabExt = null;
var port = null;

function createExtension() {
	if (tabExt != null) {
		chrome.tabs.update(tabExt.id, {selected: true});
		chrome.windows.update(tabExt.windowId, {focused: true});

		return false;
	}

	chrome.browserAction.setBadgeText({text: "run"});
	chrome.browserAction.setTitle({title: "alfa-chrome-app-wnd"});

	chrome.tabs.create({url:chrome.extension.getURL("index.html")}, function(tab) {
		console.log("Tab created", tab);
		tabExt = tab;

		var onBeforeRequest_callback = function(details) {
				// Not interesting to share with Assistant Desktop
				if (details && isInternalUsageUrl(details.url)) {
					return {};
				}
				if (details.tabId && details.tabId > 0) {
					if (!port) {
						console.warn('onBeforeRequest_callback: No port for postMessage (request)');
					} else {
						chrome.tabs.get(details.tabId, function (tab) {
							port.postMessage({Type: 'Request', Details: details, TabInfo: tab});
						});
					}
				} else {
					if (!port) {
						console.warn('onBeforeRequest_callback: No port for postMessage (request, tabId=0)');
					} else {
						port.postMessage({Type: 'Request', Details: details});
					}
				}
				return {};
			},
			onBeforeSendHeaders_callback = function(details) {
				// Not interesting to share with Assistant Desktop
				if (details && isInternalUsageUrl(details.url)) {
					return {};
				}

				console.warn('onBeforeSendHeaders_callback', callerParams && callerParams.userAgentParamURL ? callerParams.userAgentParamURL : 'NO User-Agent', details.url);
				let ret = {};
				for (let i = 0; i < details.requestHeaders.length; ++i) {
					if (callerParams && callerParams.userAgentParamURL && details.requestHeaders[i].name.toUpperCase() === 'USER-AGENT') {
						//details.requestHeaders.splice(i, 1);
						details.requestHeaders[i].value = callerParams.userAgentParamURL;
						console.warn('#User-Agent changed to', details.requestHeaders[i].value);
						ret = { requestHeaders: details.requestHeaders };
						break;
					}
				}

				if (!port) {
					console.warn('onBeforeSendHeaders_callback: No port for postMessage (sendHeaders)');
				} else {
					port.postMessage({Type: 'SendHeaders', Details: details});
				}
				return ret;
			},
			onHeadersReceived_callback = function(details) {
				if (!port) {
					console.warn('onHeadersReceived_callback: No port for postMessage (received)');
				} else {
					port.postMessage({Type: 'Received', Details: details});
				}
				return {};
			},
			onCompleted_callback = function(details) {
				const url = details && details.url ? details.url : '?';
				// Not interesting to share with Assistant Desktop
				if (details && isInternalUsageUrl(details.url)) {
					return {};
				}
				//var res = searchText();
				//port.postMessage({Type: 'Completed', Details: res});
				console.log(new Date().getTime() + 'onCompleted_callback status, port', port, url);
				if (!port) {
					console.warn('onCompleted_callback: No port for postMessage (completed)');
				} else {
					port.postMessage({Type: 'Completed', Details: details});
				}
				// Get page source
				srcUpdated(null, null, null, details, port);
				return {};
			},
			onErrorOccurred_callback = function(details) {
				if (!port) {
					console.warn('onErrorOccurred_callback: No port for postMessage (errorOcurred)');
				} else {
					port.postMessage({Type: 'ErrorOccurred', Details: details});
				}
				return {};
			},
			//TODO??
			// onResponseBodyReceived_callback = function(details) {
			// 	port.postMessage({Type: 'ResponseBodyReceived', Details: details});
			// 	return {};
			// },

			onCreated_callback = function(tab) {
				setTimeout(() => {
					try {
						muteTab(tab.id);

						/*chrome.tabs.query({}, function(tabs) {
							// Exclude non necesary tabs
							for (let tab of tabs) {
								if (!tab.url.includes("alfa-chrome-app-wnd") && !tab.url.includes("chrome-extension://") && !tab.url.includes("devtools://")) {
									muteTab(tab.id);
								}
							}
						});*/
					} catch (e) {};
				}, 200);
			},

			onWebCommitted_callback = function(details) {
				/*if(details.frameId !== 0) {
					// Ignore navigation in subframes
					return;
				}
				muteTab(details.tabId);*/
			},

			onUpdated_callback = function(tabId, changeInfo, tab) {
				const url = tab && tab.url ? tab.url : '?';
				if (tab && isInternalUsageUrl(tab.url)) {
					return {};
				}
				if (isAllowedSourceByUrl(url)) {
					console.log(new Date().getTime() + 'onUpdated_callback changeInfo.status:', changeInfo.status, url);
				}
				// console.log('!!', changeInfo.status);
				if (changeInfo.status == "complete" && tab.id == tabExt.id) {
					port = chrome.tabs.connect(tab.id);

					// Get page source
					srcUpdated(tabId, changeInfo, tab, null, port);
				}
			},
			onRemoved_callback = function(tabId) {
				if (tabId == tabExt.id) {
					tabExt = null;
					//chrome.tabs.remove(tabId);
					chrome.webRequest.onBeforeRequest.removeListener(onBeforeRequest_callback);
					chrome.webRequest.onBeforeSendHeaders.removeListener(onBeforeSendHeaders_callback);
					chrome.webRequest.onHeadersReceived.removeListener(onHeadersReceived_callback);
					chrome.webRequest.onCompleted.removeListener(onCompleted_callback);
					chrome.webRequest.onErrorOccurred.removeListener(onErrorOccurred_callback);
					//chrome.webRequest.onResponseBodyReceived.removeListener(onResponseBodyReceived_callback);
					chrome.tabs.onUpdated.removeListener(onUpdated_callback);
					chrome.tabs.onRemoved.removeListener(onRemoved_callback);

					// Mute new tab
					chrome.tabs.onCreated.removeListener(onCreated_callback);
					// chrome.webNavigation.onCommitted.removeListener(onWebCommitted_callback);

					chrome.browserAction.setBadgeText({text: ""});
					chrome.browserAction.setTitle({title: "alfa-chrome-app-wnd"});
				}
			};

		chrome.tabs.onUpdated.addListener(onUpdated_callback);
		chrome.tabs.onRemoved.addListener(onRemoved_callback);
		chrome.tabs.onCreated.addListener(onCreated_callback);
		// chrome.webNavigation.onCommitted.addListener(onWebCommitted_callback);

		chrome.webRequest.onBeforeRequest.addListener(
			onBeforeRequest_callback,
			{urls: ["<all_urls>"]},
			["blocking", "requestBody"]
		);

		chrome.webRequest.onBeforeSendHeaders.addListener(
			onBeforeSendHeaders_callback,
			{urls: ["<all_urls>"]},
			["blocking", "requestHeaders", "extraHeaders"] 			/* opt_extraInfoSpec: */
		);

		chrome.webRequest.onHeadersReceived.addListener(
			onHeadersReceived_callback,
			{urls: ["<all_urls>"]},
			["blocking", "responseHeaders"]
		);

		chrome.webRequest.onCompleted.addListener(
			onCompleted_callback,
			{urls: ["<all_urls>"]},
			["responseHeaders"]
		);

		chrome.webRequest.onErrorOccurred.addListener(
			onErrorOccurred_callback,
			{urls: ["<all_urls>"]}
		);

		//NOT YET IMPLEMENTED
		// chrome.webRequest.onResponseBodyReceived.addListener(
		// 	onResponseBodyReceived_callback,
		// 	{urls: ["<all_urls>"]}
		// );
	});

	function muteTab(tabId) {
		// try {
		// 	async (tabId) => {
		// 		await chrome.tabs.update(tabId, {true});
		// 	}
		// } catch (e) {}
		try {
			chrome.tabs.update(tabId, {muted: true});
		} catch (e) {}
		console.log('Muted tab ', tabId);
	}

	function unmuteTab(tabId) {
		// try {
		// 	async (tabId) => {
		// 		chrome.tabs.update(tabId, {false});
		// 	}
		// } catch (e) {}
		try {
			async (tabId) => {
				chrome.tabs.update(tabId, {muted: false});
			}
		} catch (e) {}
	}

	function searchText() {
		var res = [];
		var toSearch = 'm3u8';
		Object.keys(window).forEach(function(key) {
			try {
				var value = window[key];
				if (value != null && typeof value == 'string' && value.includes(toSearch)) {
					res.push(key + ' FOUND IN STRING');
					console.log('>>>' + key, value);
				}
				else if (value != null && Array.isArray(value)) {
					value.forEach(function(val) {
						if (val != null && typeof val == 'string' && val.includes(toSearch)) {
							res.push(key + ' FOUND IN ARRAY');
							console.log('>>>' + key, val);
						}
					});
				}
				//console.log(key);
			} catch (exception) {
				res.push(key + ' ERROR');
				console.error('>>>' + key + ' - Error: ', exception);
			}
		});
		return res;
	}

	function srcUpdated(tabId, changeInfo, tab, details, port) {
		var url = tab ? tab.url : (details ? details.url : null);
		if (isAllowedSourceByUrl(url) || isAllowedResourceByUrl(url)) {
			var source;
			var method = details.method ? details.method : null;
			var headers = null;	//TODO !!!

			if (isAllowedResourceByUrl(url)) {
				console.log('URL (ResourceUrl) Extra:', port, url);
				// port.postMessage({Type: 'BodyContent', Details: { url: url, body: _result, method: method, headers: headers}});	// headerFromChrome: url, dataFromChrome: body
				sendInfoToAssDesktopByPort(port, {
					url: url,
					body: null,
					method: method,
					headers: headers,
					contentUpdated: false
				});
				return;
			}

			if (url.startsWith("file://")) {
				source = {
					file: url
				}
			} else {
				source = {
					code: "document.documentElement.innerHTML" // or 'file: "myfile.js"'
				}
			}
			chrome.tabs.executeScript(source, function (result) {
				try {
					var lastError = chrome.runtime.lastError;
					if (lastError) {
						var err = "??_on_runtime_lastError";
						try {
							if (lastError.message) {
								err = lastError.message;
							} else {
								err = lastError;
							}
						} catch (ee) {
						}

						console.error('Source:', port, url, err);
						//port.postMessage({Type: 'BodyContent', Details: {url: url, body: "ERROR__" + err, method: method, headers: headers}});
						sendInfoToAssDesktopByPort(port, {
							url: url,
							body: 'ERROR__' + err,
							method: method,
							headers: headers,
							contentUpdated: false
						});

					} else if (!result) {
						console.error('No source:', port, url, err);
						// port.postMessage({Type: 'BodyContent', Details: { url: url, body:  "ERROR_NO_SOURCE", method: method, headers: headers}});
						sendInfoToAssDesktopByPort(port, {
							url: url,
							body: "ERROR_NO_SOURCE",
							method: method,
							headers: headers,
							contentUpdated: false
						});

					} else {
						if (isAllowedSourceByUrl(url, result)) {
							console.log('Source (BodyContent) Extra:', port, url);
							// port.postMessage({Type: 'BodyContent', Details: { url: url, body: _result, method: method, headers: headers}});	// headerFromChrome: url, dataFromChrome: body
							sendInfoToAssDesktopByPort(port, {
								url: url,
								body: result,
								method: method,
								headers: headers,
								contentUpdated: false
							});
						} else {
							console.warn('NOT Source (BodyContent not HTML):', port, url, result);
							// port.postMessage({Type: 'BodyContent', Details: { url: url, body: "ERROR_NO_ACCESS", method: method, headers: headers}});
							sendInfoToAssDesktopByPort(port, {
								url: url,
								body: "ERROR_NO_ACCESS",
								method: method,
								headers: headers,
								contentUpdated: false
							});
						}
					}
				} catch (e) {
					var err = "";
					try {
						err = e.message;
					} catch (ee) {
					}
					console.warn('ERROR__' + err, url);
					// port.postMessage({Type: 'BodyContent', Details: { url: url, body: "ERROR__" + err}});
					sendInfoToAssDesktopByPort(port, {
						url: url,
						body: 'ERROR__' + err,
						method: method,
						headers: headers,
						contentUpdated: false
					});
				}
			});
		} else {
			// We don't care about them
		}
	}

	return {};
}

chrome.browserAction.onClicked.addListener(function() {
	createExtension();
});

// if (chrome != null && chrome.tabs != null) {
// 	//console.log(chrome.tabs);
// 	//chrome.tabs.create({url: "chrome://extensions/?id=" + chrome.runtime.id});
//     //chrome.tabs.create({url: "chrome-extension://" + chrome.runtime.id + "/index.html"});
// 	// Auto start
// 	//window.open("chrome-extension://ndfgffclcpdbgghfgkmooklaendohaef/index.html");
// 	//setTimeout(() => {
// 		chrome.tabs.create({url: "index.html"});
// 	//}, 1000);
// 	console.log(chrome.runtime.id + ' hecho');
// }

////////////////// Functions from: https://developer.chrome.com/docs/extensions/reference/tabs/ //////////////////////////////
function toggleMuteState(tabId) {
	chrome.tabs.get(tabId, async (tab) => {
		let muted = !tab.mutedInfo.muted;
		await chrome.tabs.update(tabId, { muted });
		console.log(`Tab ${tab.id} is ${ muted ? 'muted' : 'unmuted' }`);
	});
}

// This method needs V3 manifest
async function getCurrentTab() {
	let queryOptions = { active: true, currentWindow: true };
	let [tab] = await chrome.tabs.query(queryOptions);
	return tab;
}

//TODO send cookies
var allCookies = [];	// The important to receive in the other side is the name and value. The URL used could be "url" and if it is null or empty (before Chrome 88) use "domain" (which could be also empty because it is a host-only cookie) Reference: https://developer.chrome.com/docs/extensions/reference/cookies/#type-Cookie
async function getAllCookies() {
	await chrome.cookies.getAll({}, function (cookies) {
			console.log("@getCookies. Total cookies found: " +  cookies.length);
			for (cookie of cookies) {
				if (!cookie.domain.includes('chrome-extension')) {
					allCookies.push(cookie);
				}
				// console.log("[COOKIE] => " + JSON.stringify(cookie));
			};
			//shareCookiesWithServer(cookies);
		}
	);
}
getAllCookies();
if (chrome && chrome.cookies && chrome.cookies.onChanged) {
	chrome.cookies.onChanged.addListener(function(changeInfo) {
		// alert(JSON.stringify(changeInfo.cookie))
		allCookies.push(changeInfo.cookie);
	});
}
if (chrome && chrome.history && chrome.history.onVisited) {
	chrome.history.onVisited.addListener(function(historyItem) {
		if (!historyItem || !historyItem.url) {
			console.warn('historyItem from chrome.history is null');
			return;
		} else {
			chrome.cookies.getAll({
				'url': historyItem.url	//PS: url always will end with "/"  (https://stackoverflow.com/questions/3041228/chrome-extension-and-history-onvisited-event)
			}, function (cookies) {
				console.log("@history.onVisited Total cookies found: " +  cookies.length + " for " + historyItem.url);
				allCookies = allCookies.concat(cookies);
				//shareCookiesWithServer(cookies);
			});
		}
	});
} else {
	console.warn('chrome.history is not available');
}

// chrome.runtime.onConnect.addListener(function(port) {
// 	console.log('##BK - Extension added Listener onConnect for port ', port);
// 	port.onMessage.addListener(function (Message) {
// 		console.log('##BK - Extension trigered Listener onMessage for message', Message);
// 	})
// })

// Auto-open extension (equivalent to "window.open("chrome-extension://ndfgffclcpdbgghfgkmooklaendohaef/index.html");")
createExtension();

/* Only a Chrome app is able to open sockets!!! */
// chrome.sockets.tcpServer.create({}, function(info) {
// 	console.log("#Alfa Extension Webserver started");
// 	chrome.sockets.tcpServer.listen(info.socketId, '127.0.0.1', 48881, function(data) {
// 		console.log("#Alfa Extension Webserver received", data);
// 		console.warn(data);
// 	});
// });
/* manifest.json ========
"sockets": {
      "tcpServer" : {
         "listen": ["127.0.0.1:48881"]
      }
},*/

var callerParams = {};
// watchMainCallerParams(({oldCookieValue, newCookieValue, callerParams})=> {
// 	if (callerParams) {
// 		try {
// 			console.warn('Alfa Extension Webserver: new callerParam just landed', callerParams);
//
// 			// Load new window url
// 			if (!callerParams.urlParamDEBUG) {
// 				// Stop console output
// 				disableConsole();
// 			}
//
// 		} catch (e) {
// 			console.error('ERROR: Alfa Extension Webserver: issue getting callerParam:', newCookieValue, 'Error:', e);
// 		}
// 	} else {
// 		callerParams = {};
// 	}
// }, 1000);
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
	if (message && message.type && message.type == "callerParams") {
		try {
			callerParams = message.data;
			console.warn('Alfa Extension Webserver: new callerParam just landed', callerParams);

			// Load new window url
			if (!callerParams.urlParamDEBUG) {
				// Stop console output
				disableConsole();
			}
		} catch (e) {
			console.error('ERROR: Alfa Extension Webserver: issue getting callerParam: Error:', e);
		}

		try {
			sendResponse({acknowledgeFrom: 'background'});
		} catch (e) {
			console.error('ERROR: Alfa Extension Webserver: issue acknowleding callerParam: Error:', e);
		}
	}
	return true;
});
